#include "parser.h"
#include <cstring>


Parser::Parser(Lexer& lexerx, ostream& outx): lexer(lexerx), out(outx), lindex(1), tindex(1) {
  token = lexer.nextToken();
  
}

Parser::~Parser() {
}

void Parser::error(string message) {
  cerr << message << " Found " << token.getLexeme() << " at line " << token.getLine() << " position " << token.getPos() << endl;
  exit(1);
}

void Parser::check(int tokenType, string message) {
  if (token.getType() != tokenType)
    error(message);
}
const string Parser::ops[] = {"ADD", "SUB", "MULT", "DIV",

		      "ISEQ", "ISNE", "ISLT", "ISLE", "ISGT", "ISGE",

		      "AND", "OR",

		      "PUSHL", "PUSHV", "STORE",

		      "JUMP", "JUMPF", "JUMPT", "CALL", "RET",

		      "PRINTF",

		      "LABEL", "SEQ" };





Parser::TreeNode* Parser::whileStatement() {
  TreeNode* whileNode;
  int type= token.getType();
  token= lexer.nextToken();
  string L1= makeLabel();
  string L2;
  if(type== Token::LPAREN){
    token= lexer.nextToken();
    L1= L1 + ":";
    TreeNode* Label1= new TreeNode(LABEL, L1);
    TreeNode* right= logicalExpression();
    TreeNode* seq= new TreeNode(SEQ, Label1, right);
    token= lexer.nextToken();
    if( type== Token::RPAREN){
      TreeNode* node= block();
      L2= makeLabel();
      TreeNode* jumpf= new TreeNode(JUMPF, L2);
      TreeNode* seq2= new TreeNode(SEQ, jumpf, node);
       TreeNode* seq3= new TreeNode(SEQ, seq, seq2);
      L1= makeLabel();
      TreeNode* jump= new TreeNode(JUMP,L1);
      L2= L2+ ":";
      TreeNode* Label2= new TreeNode(LABEL, L2);
      TreeNode* seq4= new TreeNode(SEQ, jump, Label2);
      whileNode= new TreeNode(SEQ, seq3, seq4);
    }
    else{
      whileNode= NULL;
    }
  }
  else{
    whileNode= NULL;
  }

  

  return whileNode;
}

Parser::TreeNode* Parser::ifStatement() {
  TreeNode* ifNode;
  int type= token.getType();
  token= lexer.nextToken();
  string L1;
  string L2;
  if(type== Token::LPAREN){
    token= lexer.nextToken();
    TreeNode* left= logicalExpression();
    L1= makeLabel();
    TreeNode* falses= new TreeNode(JUMPF, L1);
    TreeNode* seq1= new TreeNode(SEQ, left, falses);
    token= lexer.nextToken();
    if(type== Token::RPAREN){
      TreeNode* node = block();
      TreeNode* seq2= new TreeNode(SEQ, seq1, node);
   token=lexer.nextToken();
   int type2= token.getType();
   if(type2== Token::ELSE){
	L2= makeLabel();
	TreeNode* node1= new TreeNode(JUMP, L2);
	TreeNode* seq3= new TreeNode(SEQ,seq2, node1);
	L1= L1 + ":";
	TreeNode* Label1= new TreeNode(LABEL,L1);
	TreeNode* seq4= new TreeNode(SEQ, seq3, Label1);
	TreeNode* node3= block();
	TreeNode* seq5= new TreeNode(SEQ, seq4, node3);
	L2= L2+ ":";
	TreeNode* Label2= new TreeNode(LABEL, L2);
        ifNode= new TreeNode(SEQ, seq5, Label2);
	
      }
      else{
	L1= L1+ ";";
	TreeNode* Label1= new TreeNode(LABEL,L1);
        ifNode= new TreeNode(SEQ, seq2, Label1);

      }
    }
    else{
      return NULL;
    }
  }
  else{
    return NULL;
  }
  return ifNode; 
}
      
    


Parser::TreeNode* Parser::block() {
  int type = token.getType();
  TreeNode* node;

  if(type== Token::LBRACE){
    node= statement();
    check(Token::RPAREN, "Expecting )");
  
}
  else{
    return NULL;
  }
  return node;
}


Parser::TreeNode* Parser::assignStatement() {
  
  int tokentype = token.getType();
  TreeNode* node;
  TreeNode* returnnode;
  if(tokentype== Token::IDENT){
    token= lexer.nextToken();
    if(tokentype== Token::ASSIGN){
      token= lexer.nextToken();
      node= logicalExpression();
      token= lexer.nextToken();
      if(tokentype== Token::SEMICOLON){
	returnnode= node;
      }
      else{
	return NULL;
      }
    }
  else{
    return NULL;
  }

  }
  return returnnode;
}




Parser::TreeNode* Parser::statement() {
  TreeNode* statement;

  int type= token.getType();
  cout<<type<< endl;
  
  while(type== Token::IDENT || type == Token::WHILE || type== Token::IF){

switch(type){
    case Token::IDENT:

      
      statement= assignStatement();
      break;
    case Token::WHILE:

      
      statement= whileStatement();
      break;
    case Token::IF:
      
      statement= ifStatement();
      break;
 default:
   error(token.getLexeme());
   break;
   
    }
 
    
  }
  return statement;
}


Parser::TreeNode* Parser::factor() {
 TreeNode* node;
int tokentype = token.getType();
 switch(tokentype){

 case Token::LPAREN :
check(Token::LPAREN, "Expecting (");
token= lexer.nextToken();
node= expression();
token= lexer.nextToken();
check(Token::RPAREN, "Expecting )");
break;

 case Token::INTLIT :
   node = new TreeNode(PUSHL, token.getLexeme());
break;

 case Token::IDENT :
   node= new TreeNode(PUSHV, token.getLexeme());
 break;
   }
token= lexer.nextToken();
return node;
}

Parser::TreeNode* Parser::term() {
  TreeNode* term = factor();
  TreeNode* factors;
  int tokentype= token.getType();
  while(tokentype == Token::TIMES || tokentype== Token::DIVIDE){
    token= lexer.nextToken();
    factors= factor();
    Operation op;
    switch (tokentype){
    case Token::TIMES :
      op= MULT;
    break;
    case Token::DIVIDE :
      op= DIV;
    break;
    }
    term = new TreeNode(op, term, factors);
    tokentype= token.getType();
  }
  return term;
}
Parser::TreeNode* Parser::logicalExpression() {
  TreeNode* logic= relationalExpression();
  TreeNode* rel;
  int tokentype= token.getType();
   Operation op;
  while(tokentype == Token::AND || tokentype== Token::OR){
    token= lexer.nextToken();
    rel = relationalExpression();
    switch (tokentype){
    case Token::AND :
      op= AND;
    break;
    case Token::OR :
      op= OR;
    break;
    }
    logic = new TreeNode(op, logic, rel);
    tokentype= token.getType();
  }
  return logic;
}



Parser::TreeNode* Parser::expression() {
  TreeNode* expression = term();
  TreeNode* terms;
  int type= token.getType();
 Operation op;
  while(type == Token::PLUS || type== Token::MINUS){
    token= lexer.nextToken();
    terms= term();
    switch(type){
    case Token::PLUS :
      op= ADD;
    break;
    case Token::MINUS :
      op= SUB;
    break;
    }
    expression= new TreeNode(op, expression, terms);
    type= token.getType();
  }
  return expression;
}





Parser::TreeNode* Parser::relationalExpression() {
  TreeNode* relation= expression();
  TreeNode* node;
  int type = token.getType();

  
    token= lexer.nextToken();
    node= expression();
    Operation op;
    switch(type){
    case Token::EQ :
      op= ISEQ;
    node = expression();
    break;
    case Token::LT :
      op= ISLT;
    node = expression();
    break;
    case Token::LE :
      op= ISLE;
        node = expression();
    break;
    case Token::GT :
      op= ISGT;
        node = expression();
    break;
    case Token::GE :
      op= ISGE;
        node = expression();
    break;
    case Token::NE :
      op= ISNE;
        node = expression();
    break;
    
    relation= new TreeNode(op, relation, node);
    type= token.getType();
    }
  
  return relation;
    	
}

