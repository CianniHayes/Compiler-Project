#include <iostream>
using namespace std;

int main(int argc, char** argv) {

  char name[] = "this is a test";
  char* a = name;
  char* b = a;
  char c = *b;
  char* x = 0;

  cout << c << endl;
  cout << *b << endl;
  cout << b << endl;
  cout << name << endl;
  cout << "***" << name[13] << "***"<< endl;
  cout << *x;
  return 0;
}
