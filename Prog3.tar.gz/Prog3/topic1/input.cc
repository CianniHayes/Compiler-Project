#include <iostream>

using namespace std;

int main(int argc, char** argv) {

  int age;
  string cell;

  cout << "Hi there" << "Please enter your age and cell number: \n";

  cin >> age >> cell;

  cout << "My age is " << age << endl;
  cout << "My cell is " << cell << endl;
  
  return 0;
}
