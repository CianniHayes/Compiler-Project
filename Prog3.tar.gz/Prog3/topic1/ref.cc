#include <iostream>

using namespace std;

int main(int argc, char** argv) {
  int y = 5;
  int z = 8;
  int& x = y;
  x = 10;
  cout << x << " " << y << endl;
  x = z;
  cout << x << " " << y << " " << z << endl;
  return 0;
}
