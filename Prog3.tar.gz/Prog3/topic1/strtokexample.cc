#include <iostream>
#include <cstring>

using namespace std;

int main(int argc, char** argv) {

  char str[]  = "This            is a test";
  char* token = strtok(str, " ");
  while (token != NULL) {
    cout << token << endl;
    token = strtok(NULL, " ");
  }

  return 0;
}
