#include <iostream>

using namespace std;

int main(int argc, char** argv) {
  int x = 5;
  cout << "Hello, " << " World! " << x << endl;
  cerr << "Oh, no, I made a mistake\n";
  for (int i=0; i < argc; ++i) {
    cout << "arg[" << i << "]= " << argv[i] << endl;
  }
  return 0;
}
// scope resolution operator std::cout
// cout === stdout
// << insertion operator
