#include <iostream>

using namespace std;

int add(int&, int);

const double Pi = 3.14159265358979323;

int main() {
  int a, b;
  cin >> a >> b;
  cout << add(a, b) << endl;
  cout << a << endl;
}

int add(int i1, int i2, int i3=3) {
  return i1 + i2 + i3;
}

int add(int i1, const int i2=5 ) {
  int sum, x=5;
  int a[5];
  //int[] a = new int[5];
  i1 = 2;
  if (x > 2) {
    int y;
  } else {
  }
  return i1 + i2;
}
