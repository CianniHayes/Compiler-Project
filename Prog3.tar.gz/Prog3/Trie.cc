#include <cstdlib>
#include <stdio.h>
#include "Node.h"
#include "Trie.h"
#include <iostream>


Trie::Trie(){
  start = new Node;
}
Trie::~Trie(){
  delete start;
}

void Trie::put(string key, int value){
  Node* spot = start;
  bool match = false;
  int size= key.length();
   for( int i= 0; i< size; i++){
     for(int j= 0; j< spot->count; j++){
       if(spot->node[j]->next == key[i]){
	 spot= spot->node[j]->move;
	 match = true;
       }
     }
     if(match==false){
       Link* after= new Link(key[i], new Node());
       spot-> node[spot -> count]= after;
       spot-> count++;
       spot= after-> move;
     }
     match=false;
   }
     spot-> nodevalue = value;
   
}
int Trie::get(string key){
  Node* spot = start;
  bool match = false;
  int size= key.length();
  int value= -1;
  for( int i= 0; i< size; i++){
    for(int j= 0; j< spot->count; j++){
      if(spot->node[j]->next == key[i]){
	spot= spot->node[j]->move;
	match = true;
      }
    }
    if(match==false){
      return value;
    }
    match= false;
  }
  value= spot-> nodevalue;
  return value;
  
  
}
