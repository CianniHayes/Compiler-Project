#ifndef LINK_H
#define LINK_H
#include "Node.h"
#include <iostream>
using namespace std;

class Link {
public:
  Link(char letter, Node* point);
  Link();
  ~Link();
  char next;
  Node* move;
};  

#endif
