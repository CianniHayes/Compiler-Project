/*
    CSE 109
      Cianni Hayes
        873940065
	  Program Description:
	    Program #3
*/
#ifndef Trie_H
#define Trie_H
#include "Node.h"
#include "Link.h"
#include <iostream>
using namespace std;

class Trie{
public:
  Node* start;
  Trie();
  ~Trie();
  void put(string key, int value);
  int get(string key);

};

#endif













