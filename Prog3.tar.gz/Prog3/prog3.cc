/*
CSE 109
Your name
Your user id
Program Description:
Program #3
 */

#include <iostream>
#include "Trie.h"
using namespace std;

int main(int argc, char ** argv){
  Trie t;
  t.put("Lehigh", 1);
  t.put("Lemon", 2);
  cout << t.get("Lehigh") << endl;
  cout << t.get("Lemon") << endl;
  cout << t.get("Leh") << endl;
  cout << t.get("i") << endl;

}

