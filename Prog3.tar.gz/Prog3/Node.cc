#include <cstdlib>
#include <stdio.h>
#include "Node.h"
#include <iostream>

Node::~Node(){
  // if(this->count !=0){
    // for(int i= 0; i<count; i++){
      //	delete node[i];
	// }
    //  }
}

Node::Node(){
  nodevalue= -1;
  count=0;
}

Node::Node(int val){
  nodevalue= val;
  count=0;
}


