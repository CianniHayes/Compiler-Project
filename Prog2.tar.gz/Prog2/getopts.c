#include <stdio.h> 
#include <string.h>
#include <stdlib.h>
/*
  CSE 109
  Cianni Hayes
  Cih219
  Program Description:  It reads the input on the command line and
    executes the command.
  Program #2
*/


char ** getopts(char cmd[]){
  char copied[strlen(cmd)];
  strcpy(copied, cmd);
  char  * token = strtok(copied, " ");
  int numoftok=0;

  while(token != NULL){
      numoftok++;
      puts(token);
      token= strtok(NULL, " ");
  }
  char ** newargv= (char **)(malloc((numoftok+1) * (sizeof ( char *))));
  strcpy(copied, cmd);
  token = strtok(copied, " ");
  int count=0;
  while(token){
  newargv[count]=( char *)(malloc((strlen(token)) * (sizeof ( char))));

  strcpy( newargv[count], token);
  puts(newargv[count]);
 
   token= strtok(NULL, " ");
   count++; 
 }
 
 newargv[numoftok+1]="\0";

    return newargv;
}

