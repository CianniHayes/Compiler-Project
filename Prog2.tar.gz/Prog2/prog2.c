#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

/*
  CSE 109
  Cianni Hayes
  Cih219
  Program Description:  It reads the input on the command line and
    executes the command.
  Program #2
*/

char ** getopts(char cmd[]);
int main( int argc, char ** argv){
  char hostname[255];
  gethostname(hostname, sizeof hostname);
   char readfile[255];  
   do{
   printf(hostname);

     printf(">");

     fgets(readfile, sizeof readfile, stdin);

     
     int removeline= strlen(readfile)-1;
     if(readfile[removeline]== '\n'){
       readfile[removeline] = '\0';
	 }
     char * exit = "exit";
     int comparison= strcmp(readfile , exit);
     if(comparison!= 0){

       char ** newargv;
       newargv=getopts(readfile);
       if (fork() == 0) {
	 
	 execvp(newargv[0], newargv);
	 
	 
       } else {
	 wait(NULL);
       }
       
	  }
   } while (strcmp(readfile, "exit")!= 0);
     

  return 0;
}
