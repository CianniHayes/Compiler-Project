/*
  CSE 109
  Cianni Hayes 
  cih219
  Program Description:This program checks if the input was -u pr -l to
  deter,ime of it should capatilize the string or make it lowercase
  Program #1
*/

#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main (int argc, char ** argv){
   int i= 0;
  

   

   if (argc > 2){
       
     
    fputs("Invalid Command Line Option", stderr);
    
    return 1;
    }
    
  
    
  
  if(argc==1){
    
    int same;
    while((same= getchar())!= EOF){
      putchar(same);
    }
    return 0;
    }
  
  int strval=strcmp( argv[1], "-u");
  
  int strval2=strcmp( argv[1], "-l");
  

  if (strval != 0 && strval2 != 0) {
    fputs("Invalid Command Line Option", stderr);
    
    return 1;
  }
  int ups;
  int lows;
  
  
   while (( i =getchar())!= EOF){
     
     if( strval== 0){
	 ups= toupper(i);
	
	putchar(ups);
       
	
     } else
     if( strval2== 0){
       lows= tolower(i);
       putchar(lows);
     }
   }
   return 0; 
}

  
