#include "parser.h"
#include <cstring>
#include "stack.h"

Parser::Parser(Lexer& lexerx, ostream& outx): lexer(lexerx), out(outx), lindex(1), tindex(1) {
  token = lexer.nextToken();

}

Parser::~Parser() {
}

void Parser::error(string message) {
  cerr << message << " Found " << token.getLexeme() << " at line " << token.getLine() << " position " << token.getPos() << endl;
  exit(1);
}

void Parser::check(int tokenType, string message) {
  if (token.getType() != tokenType)
    error(message);
}
const string Parser::ops[] = {"ADD", "SUB", "MULT", "DIV",

			      "ISEQ", "ISNE", "ISLT", "ISLE", "ISGT", "ISGE",

			      "AND", "OR",

			      "PUSHL", "PUSHV", "STORE",

			      "JUMP", "JUMPF", "JUMPT", "CALL", "RET", "PARAM1", "PARAM2", "PARAM3", "PARAM4", "PARAM5"

			      "PRINTF",

			      "LABEL", "SEQ" };

Parser::TreeNode* Parser::funcall(string functionName){
  TreeNode* functions;
  TreeNode* callNode;

  check(Token::IDENT, "Expecting ident");
  token= lexer.nextToken();

  check(Token::LPAREN, "Expecting (");
  if(token.getType()==Token::LPAREN)
    token=lexer.nextToken();
  if(token.getType()!= Token::RPAREN){
    while(token.getType()!= Token::RPAREN){
      callNode= new TreeNode(CALL, functionName);
      TreeNode* exp=  expression();
      functions= new TreeNode(SEQ,exp, callNode);
    }
  }
  else{
    functions= new TreeNode(PUSHV, token.getLexeme());
  }
  return functions;



}

Parser::TreeNode* Parser::function(){
  //enter scope before you process the parameters
  TreeNode* functions;
  //  TreeNode* blocks;

  check(Token::FUNCTION, "Expecting function");
  token = lexer.nextToken();
  check(Token::IDENT, "Expecting ident");
  functions = new TreeNode(CALL, token.getLexeme());

  token=lexer.nextToken();
  check(Token::LPAREN, "Expecting (");

  token = lexer.nextToken();
  TreeNode *temp = parameterdefs();
  if(temp != NULL) {
    return NULL;
  }
  else{
    functions= new TreeNode(PARAM1, token.getLexeme());
  }
  check(Token::RPAREN, "Expecting )");
  // blocks= block();
  functions= new TreeNode(SEQ, functions, block());
  //exit scope
  return functions;

}

Parser::TreeNode* Parser::parameterdefs(){

  TreeNode *node = parameterdef();
  if(node == NULL) {
    return NULL;
  }

  while (token.getType() == Token::COMMA) {
    node = new TreeNode(SEQ, node, parameterdef());
  }

  return node;
}

Parser::TreeNode* Parser::returnStatement(){
  TreeNode* returnNode= NULL;
  TreeNode* logic;
  check(Token::RETURN, "Expecting return");
  token= lexer.nextToken();
  logic= logicalExpression();
  check(Token::SEMICOLON, "Expecting ;");
  returnNode= new TreeNode(SEQ,returnNode, logic);
  token= lexer.nextToken();
  return returnNode;
}
Parser::TreeNode* Parser::vardefStatement(){

  TreeNode* var;
  TreeNode* node;
  check(Token::VAR, "Expecting var");
  token = lexer.nextToken();
  check(Token::IDENT, "Expecting ident");
  token = lexer.nextToken();
  while( token.getType()== Token::COMMA){
    if( token.getType()== Token::IDENT){
      node= new TreeNode(PUSHV, token.getLexeme());
      var= new TreeNode(SEQ, var, node);
    }
    else{
      return NULL;
    }
  }
  check(Token::SEMICOLON, "Expecting ;");
  return var;

}

Parser::TreeNode* Parser::compilationunit(){

  TreeNode* functions;
  check(Token::FUNCTION, "Expecting Function");
  if(token.getType()== Token::FUNCTION){
    functions= function();
  }
  else{
    cout<<"Not a function"<<endl;
  }
  return functions;
}


Parser::TreeNode* Parser::parameterdef(){
  Token temp = token;
  if(temp.getType()== Token::IDENT){
    token = lexer.nextToken();
    TreeNode* par= new TreeNode(PUSHV, temp.getLexeme());
    return par;
  }
  else {
    return NULL;
  }
}


Parser::TreeNode* Parser::whileStatement() {

  TreeNode* whileNode;
  check(Token::WHILE, "Expecting WHILE");
  token= lexer.nextToken();

  check(Token::LPAREN, "Expecting (");
  token= lexer.nextToken();

  TreeNode* logic= logicalExpression();
  check(Token::RPAREN, "Expecting RPAREN )");
  token= lexer.nextToken();
  string L1= makeLabel();
  string L2= makeLabel();

  whileNode= new TreeNode(LABEL, L1 + ":");
  whileNode= new TreeNode(SEQ, whileNode, logic);

  TreeNode* jfalse= new TreeNode(JUMPF,L2);
  whileNode= new TreeNode(SEQ, whileNode, jfalse);
  //enter
  TreeNode* blockN= block();
  //exit
  whileNode= new TreeNode(SEQ, whileNode, blockN);

  TreeNode* jumpNode= new TreeNode(JUMP, L1);
  whileNode= new TreeNode(SEQ,whileNode, jumpNode);

  TreeNode* label2= new TreeNode(LABEL, L2+ ":");
  whileNode= new TreeNode(SEQ, whileNode, label2);

  return whileNode;

}

Parser::TreeNode* Parser::ifStatement() {


  check(Token::IF, "Expecting if");
  token= lexer.nextToken();
  check(Token::LPAREN, "Expecting (");
  token= lexer.nextToken();

  TreeNode* ifNode;
  ifNode= logicalExpression();
  check(Token::RPAREN, "Expecting )");
  string l1 = makeLabel();
  string l2= makeLabel();


  TreeNode* jfalse = new TreeNode(JUMPF, l1); //jumpf l1 node
  ifNode = new TreeNode(SEQ, ifNode, jfalse); //le SEQ jumpf l1
  token= lexer.nextToken();
  //enter and exit scope
  TreeNode* block1 = block(); //blocknode
  //enter exit scope
  ifNode = new TreeNode(SEQ, ifNode, block1);// if SEQ block1
  TreeNode* label1 = new TreeNode(LABEL, l1 + ":");// label l1
  if(token.getType()==Token::ELSE){
    TreeNode* block2= block();


    TreeNode* jump = new TreeNode(JUMP, l2); //jump l2 node
    ifNode = new TreeNode(SEQ, ifNode, jump); // if SEQ jump l2
    ifNode = new TreeNode(SEQ, ifNode, label1);// if SEQ label l1
    ifNode= new TreeNode(SEQ, ifNode, block2);
    TreeNode* label2 = new TreeNode(LABEL, l2 + ":");
    ifNode = new TreeNode(SEQ, ifNode, label2);

  }
  else{
    ifNode = new TreeNode(SEQ, ifNode, label1);// if SEQ label l1
  }


  return ifNode;

}

Parser::TreeNode* Parser::block() {


  TreeNode* block;
  TreeNode* node;
  // can put enter scope
  check(Token::LBRACE,"Expecting LBRACE");
  token=lexer.nextToken();
  block= statement();
  while(token.getType() != Token::RBRACE){
    node= statement();
    block= new TreeNode(SEQ, block, node);
    token= lexer.nextToken();
  }
  return block;
  //can put wxit scope
}

Parser::TreeNode* Parser::assignStatement() {


  TreeNode* assign;
  TreeNode* id;

  check(Token::IDENT, "Must be an Identifier");
  string lex= token.getLexeme();
  token= lexer.nextToken();

  check(Token::ASSIGN, "Must be and assignment");
  id= new TreeNode(STORE, lex);
  token= lexer.nextToken();
  assign= logicalExpression();

  check(Token::SEMICOLON, "Must be a semicolon");
  assign= new TreeNode(SEQ, assign, id);
  token=lexer.nextToken();
  return assign;



}


Parser::TreeNode* Parser::statement() {
  TreeNode* statement;

  int type= token.getType();
  switch(type){
  case Token::VAR:
    statement= vardefStatement();
    break;
  case Token::IDENT:

    statement= assignStatement();
    break;
  case Token::WHILE:


    statement= whileStatement();
    break;
  case Token::IF:

    statement= ifStatement();
    break;
  default:
    error(token.getLexeme());
    break;
  }
  return statement;
}

Parser::TreeNode* Parser::factor() {
  TreeNode* node;
  int tokentype = token.getType();
  switch(tokentype){

  case Token::LPAREN :
    // node= expression();
    // token= lexer.nextToken();
    check(Token::LPAREN, "Expecting (");
    token= lexer.nextToken();
    node= expression();
    check(Token::RPAREN, "Expecting (");
    token= lexer.nextToken();
    break;
  case Token::INTLIT :
    check(Token::INTLIT, "Expecting )");
    node = new TreeNode(PUSHL, token.getLexeme());
    token= lexer.nextToken();
    break;

  case Token::IDENT :
    check(Token::IDENT, "Expecting an ident");
    string save= token.getLexeme();
    token= lexer.nextToken();
    if(token.getType()== Token::LPAREN){
      token= lexer.nextToken();
      node= funcall(save);
    }
    else{
      node= new TreeNode(PUSHV, token.getLexeme());
      token= lexer.nextToken();
    }
    break;
  }

  return node;
}









Parser::TreeNode* Parser::term() {

  TreeNode* term = factor();
  TreeNode* factors;
  int tokentype= token.getType();
  while(tokentype == Token::TIMES || tokentype== Token::DIVIDE){
    token= lexer.nextToken();
    factors= factor();
    Operation op;
    switch (tokentype){
    case Token::TIMES :
      op= MULT;
    break;
    case Token::DIVIDE :
      op= DIV;
    break;
    }
    term = new TreeNode(op, term, factors);
    tokentype= token.getType();
  }
  return term;
}
 
Parser::TreeNode* Parser::logicalExpression() {
  TreeNode* logic= relationalExpression();//
  TreeNode* rel;
  int tokentype= token.getType();
   Operation op;
  while(tokentype == Token::AND || tokentype== Token::OR){
    token= lexer.nextToken();
    rel = relationalExpression();
    switch (tokentype){
    case Token::AND :
      op= AND;
    
    break;
    case Token::OR :
      op= OR;
    break;
    }
    logic = new TreeNode(op, logic, rel);
     tokentype= token.getType();
  }
  return logic;
}



Parser::TreeNode* Parser::expression() {
  
  TreeNode* expression = term();//
  
  TreeNode* terms;
  int type= token.getType();
 Operation op;
  while(type == Token::PLUS || type== Token::MINUS){
    token= lexer.nextToken();
    terms= term();
    switch(type){
    case Token::PLUS :
      op= ADD;
    break;
    case Token::MINUS :
      op= SUB;
    break;
    }
    expression= new TreeNode(op, expression, terms);
    type= token.getType();
  }
  return expression;
}





Parser::TreeNode* Parser::relationalExpression() {
   TreeNode* relation= expression();
  TreeNode* node;
  int type = token.getType();

  
    Operation op;
    switch(type){
    case Token::EQ :
     
      token= lexer.nextToken();
      op= ISEQ;
    node = expression();
    break;
    case Token::LT :
       token= lexer.nextToken();
      op= ISLT;
    node = expression();
    break;
    case Token::LE :
       token= lexer.nextToken();
      op= ISLE;
        node = expression();
    break;
    case Token::GT :
     
      token= lexer.nextToken();
      op= ISGT;
        node = expression();
    break;
    case Token::GE :
       token= lexer.nextToken();
      op= ISGE;
        node = expression();
    break;
    case Token::NE :
       token= lexer.nextToken();
      op= ISNE;
        node = expression();
    break;
    
    relation= new TreeNode(op, relation, node);
    
    }
  
  return relation;
}   	


