#ifndef LINKS__H
#define LINKS_H
#include <iostream>
#include <fstream>
#include <string>
using namespace std;


class Links{
public:
  string  key;  //used to identify the Linkss; should be unique
  string  data;  //the actual information
  Links *next;

  /*Set key=k, data=d, next=nx*/
  Links(string k, string d = "0", Links *nx = NULL);

  /*Make a copy of the Links t. Note that we copy the pointer, thus
    not
          a deep copy
  */
  Links(const Links & t);

  /*Print out in the form  (2, 2.7)  */
  friend ostream& operator <<(ostream& out, const Links& t);
};
#endif
