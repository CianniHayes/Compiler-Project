#include <stdio.h>


int main(int arg, char **argv){


  //quick test prog
}
