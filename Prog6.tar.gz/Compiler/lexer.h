
/*
 CSE 109
 Cianni Hayes
 873940065
 Program Description: creates the lexer class variables and intializes stream
 Program #4
*/

#ifndef Lexer_H
#define Lexer_H
#include "Trie.h"
#include "token.h"
#include <stdio.h>
#include <iostream>
using namespace std;

class Lexer{

public:
  std:: istream& stream;
  Lexer(std::istream& stream1);
  Token nextToken();
  int lineNum;
  int position;
private:
  char nextChar();
  char temp;
  Trie key;
};

#endif
