
#include <stdio.h>
#include "parser.h"
#include "Trie.h"
#include "token.h"
#include "lexer.h"
#include "SymbolTable.h"
#include "stack.h"
#include "hashTable.h"


string itos(int i) { stringstream ss; ss << i; string res = ss.str(); return    res;}

SymbolTable::SymbolTable(): index(1){

}

SymbolTable:: ~SymbolTable(){
 
}

void SymbolTable::exitScope(){
  symtable.pop();



}


void SymbolTable::enterScope(){
  symtable.push(HashTable(50));
}
  


int SymbolTable::addSymbol(string sym){
  Stack symtable= getsymtable();  
  HashTable top= symtable.peek();
  if(top.inTable(sym)){
    return 0;
    
}
 
  symtable.peek().add(sym + '$' + itos(index++), "");
  return 1;
}

string SymbolTable::getUniqueSymbol(string sym){
  for(int i= symtable.getTos(); i>= 0; --i){
    HashTable sc= symtable[i];
    if(sc.inTable(sym)){
      return sc.get(sym);
    }
  }
  return " ";
}

