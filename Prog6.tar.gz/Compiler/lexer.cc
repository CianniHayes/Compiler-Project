
/*
 CSE 109
 Cianni Hayes
 873940065
 Program Description: This program breaks apart the string and assigns
 them to the specific token using the methods getChar and getToken
 Program #3
*/

#include <cstdlib>
#include <stdio.h>
#include "lexer.h"
#include "token.h"
#include "Trie.h"
#include <iostream>
#include <cctype>
#include <string>
Lexer::Lexer(std::istream &stream1):stream(stream1){
 lineNum=1;
 position=0;
 temp = nextChar();
 key.put("+",Token::PLUS);
  key.put("-",Token::MINUS );
  key.put("*", Token::TIMES);
  key.put("/", Token::DIVIDE);
  key.put("=",  Token::ASSIGN);
  key.put("==",  Token::EQ);
  key.put("!=",  Token::NE);
  key.put("<",  Token::LT);
  key.put("<=",  Token::LE);
  key.put(">",  Token::GT);
  key.put(">=",  Token::GE);
  key.put("&&",  Token::AND);
  key.put("||",  Token::OR);
  key.put("(",  Token::LPAREN);
  key.put(")",  Token::RPAREN);
  key.put("{", Token::LBRACE);
  key.put("}",Token::RBRACE );
  key.put(",", Token::COMMA);
  key.put(";", Token::SEMICOLON);
  key.put("if", Token::IF);
  key.put("else", Token::ELSE);
  key.put("while", Token::WHILE);
  key.put("function",Token::FUNCTION );
  key.put("var", Token::VAR);
  key.put("printf",Token::PRINTF );
  key.put("return", Token::RETURN);
}

char Lexer::nextChar(){
  position++;
  char character;
  character= stream.get();
  if(character == EOF)
    {
      return '#';

    }
  else{
    if(character== '\n' ){
      lineNum++;
      position =0;
      return ' ';
    }
  }
  
    return character;
  
}

Token Lexer::nextToken(){

  
  string lexeme= "";
  int type;
  
  while(isspace(temp) || temp == '#'){
    if(isspace(temp)){
      temp= nextChar();
    }
    else{
      type= Token::ENDOFFILE;
      return Token(type, "#", lineNum, position);
    }
  }
 int line= lineNum;
 int pos= position;
 if(isdigit(temp)){
   type=Token::INTLIT ;
    while(isdigit(temp)){
      lexeme= lexeme+ temp;
      temp=nextChar();
    }
    return Token(type, lexeme, line, pos);
 }
 else if(isalpha(temp)){
   while(isalpha(temp)|| isdigit(temp)){
     lexeme= lexeme +temp;
     temp= nextChar();
   }
       if(key.get(lexeme)== -1){
	 type=Token::IDENT;
	 return Token(type, lexeme, line, pos);
       }
       else{
	 type= key.get(lexeme);
	 return Token(type, lexeme, line, pos);
       }
 }
 else if(temp == '"'){
   temp= nextChar();
   while(temp!= '"'){
     lexeme= lexeme+ temp;
     temp= nextChar();
   }
   temp= nextChar();
   return Token(Token::STRINGLIT, lexeme, line, pos);

 }
 else if(ispunct(temp)){
   lexeme= lexeme + temp;
   temp = nextChar();
   if(lexeme != "(" && lexeme != ")" && lexeme != "{" && lexeme != "}" && lexeme != "," && lexeme != ";" ){ 
     while(ispunct(temp)){
       lexeme= lexeme +temp;
       temp= nextChar();
     }
   }
   if(key.get(lexeme) == -1){
     type=Token::ERROR;
     cout << "Error, character is invalid" << endl;
     cout<< lexeme<< endl;
     return Token(type, lexeme, line, pos);

   }
   type= key.get(lexeme);
   return Token(type, lexeme, line, pos);
 }
   else{
     cout<< "Error occurred" << endl;
     return Token(31, lexeme, line, pos);
   }

 }

