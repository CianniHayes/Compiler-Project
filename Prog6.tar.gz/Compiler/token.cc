
/*
CSE 109
Cianni Hayes
873940065
Program Description: defines the constructor and variables of the
token class.
Program #4
*/

#include <cstdlib>
#include <stdio.h>
#include "token.h"
#include <iostream>

Token::~Token(){
  type= NULL;
  lexeme = "";
  line = NULL;
  pos= NULL;
  
}

Token::Token(int type1 , string lexeme1, int line1, int pos1){
  type= type1;
  lexeme= lexeme1;
  line= line1;
  pos= pos1;

}
Token::Token(){
  type=0;
  lexeme= "";
  line=1;
  pos=0;

}


int Token::getType()const{
  return type;
}
int Token::getLine()const{
  return line;
}

int Token::getPos()const{
  return pos;
}
string Token::getLexeme()const{
  return lexeme;
}
