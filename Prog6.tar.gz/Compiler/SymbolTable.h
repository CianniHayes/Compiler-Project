#include <stdio.h>
#include "parser.h"
#include "Trie.h"
#include "token.h"
#include "lexer.h"
#include "stack.h"
#include "hashTable.h"


#ifndef SymbolTable_H
#define SymbolTabel_H

class SymbolTable {

public:
  
 
 void enterScope();
  void exitScope();
  int addSymbol(string sym);
  string getUniqueSymbol(string sym);
 
  
  SymbolTable();
  ~SymbolTable();


    Stack getsymtable();
private:
  Stack symtable;
  int index;
};

  
#endif 
