/*J Femister
  CSE 109 - 010
  Fall 2015
*/

#ifndef STACK_H
#define STACK_H

#include <iostream>
#include "hashTable.h"
using namespace std;

/* 
   A simple implementation of a stack for ints.
*/

// This is a comment
//template<class HashTable>
class Stack {
public:
  // Constructors
  Stack(HashTable h);
  Stack(); // Default constructor
  Stack(const Stack&); // Copy Constructor - deep copy

  // Destructor
  ~Stack();

  // Regular Member Functions
  void push(HashTable hashs);
  HashTable pop();
  HashTable peek() const;
  int getTos();
  // Inline Member Function
  bool isEmpty() const { return tos == EMPTY; } // inline member function

  // Overloaded Operator Friend Functions
  friend ostream& operator <<(ostream& out, const Stack& s);

  // Overloaded Operator Member Functions
  const HashTable operator [](int i) const; // rvalue

  HashTable operator [](int i); // lvalue
 
private:
  HashTable *stack;
  int size;
  int tos;
  //hashTable hash;
  static const int EMPTY = -1;
  void checkIndex(int i) const;
};

#endif

