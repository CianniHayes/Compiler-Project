#include "parser.h"
#include <cstring>


Parser::Parser(Lexer& lexerx, ostream& outx): lexer(lexerx), out(outx), lindex(1), tindex(1) {
  token = lexer.nextToken();
}

Parser::~Parser() {
}

void Parser::error(string message) {
  cerr << message << " Found " << token.lexeme() << " at line " << token.line() << " position " << token.pos() << endl;
  exit(1);
}

void Parser::check(int tokenType, string message) {
  if (token.type() != tokenType)
    error(message);
}

Parser::TreeNode* Parser::factor() {
}

Parser::TreeNode* Parser::term() {
}

Parser::TreeNode* Parser::expression() {
}

Parser::TreeNode* Parser::relationalExpression() {
}

Parser::TreeNode* Parser::logicalExpression() {
}

