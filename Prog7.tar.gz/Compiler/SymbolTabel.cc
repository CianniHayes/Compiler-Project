#include <stdio.h>
#include "parser.h"
#include "Trie.h"
#include "token.h"
#include "lexer.h"
#include "SymbolTable.h"
