#include "links.h"

Links::Links(string k, string d, Links* nx):key(k),data(d),next(nx){}

Links::Links(const Links& t):key(t.key),data(t.data),next(t.next){}

ostream & operator<<(ostream& out,const Links& x){
  out << "("<< x.key << ", " << x.data << ")";
  return out;
}

/*  Some simple tests of the class Link */
void show(Links *t){
  while(t != NULL){
    cout << "-->" << *t;
    t = t->next;
  }
  cout<<endl;
}
