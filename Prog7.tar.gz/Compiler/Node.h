
/*
  CSE 109
  Cianni Hayes
  873940065
  Program Description:
  Program #3
*/
#ifndef Node_H
#define Node_H

#include <iostream>
using namespace std;

class Link;
class Node {
public:
  Node(int val);
  Node();
  ~Node();
  int  nodevalue;
  Link* node[50];
  int count;
};

#endif
