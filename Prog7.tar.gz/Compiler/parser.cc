#include "parser.h"
#include <cstring>
#include "SymbolTable.h"
//#include "stack.h"
//#include "SymbolTable.h"


const string Parser::ops[] = {"ADD", "SUB", "MULT", "DIV",
			      "ISEQ", "ISNE", "ISLT", "ISLE", "ISGT", "ISGE",
			      "AND", "OR",
			      "PUSHL", "PUSHV", "STORE",
			      "JUMP", "JUMPF", "JUMPT", "CALL", "RET",
			      "PRINTF",
			      "LABEL", "SEQ",
			      "FUNC", "PARAM"};

Parser::Parser(Lexer& lexerx, ostream& outx): lexer(lexerx), out(outx), lindex(1), tindex(1) {
  token = lexer.nextToken();
}

Parser::~Parser() {
}

void Parser::error(string message) {
  cerr << message << " Found " << token.getLexeme() << " at line " << token.getLine() << " position " << token.getPos() << endl;
  exit(1);
}

void Parser::check(int tokenType, string message) {
  if (token.getType() != tokenType)
    error(message);
}
void Parser::jumpL(string s){
  string j1= makeJLabel();
  string J5= makeJLabel();
  emit("   pop rbx");
  emit("   pop rax");
  emit("   cmp rax,rbx");
 if( s == "je"){
    emit(s + j1);
  }
  else if(s == "jne"){
    emit(s + j1);
  }
  else if(s == "jl"){
   emit(s +" " + j1);
 }
  else if(s == "jle"){
    emit(s + " " + j1);
  }
  else if(s == "jg"){
    emit(s +" "+ j1);
  }
  else if(s == "jge"){
    emit(s +" " + j1);
  }

 emit("  mov rax, 0");
 emit("  jmp J5");
 emit(j1 + " : ");
 emit("  mov rax,1");
 emit(J5 + " : ");
 emit("  push rax");
}
string collect[50];
int count=0;
void Parser::vardefs(TreeNode *node){
  if(node == NULL){
    return;
  }
  vardefs(node->leftChild);
  vardefs(node->rightChild);
  Operation op= node->op;
  if(op== PUSHV){
    if(checkOps(node->val)==true){
      collect[count]= node->val;
      count++;
    }
  }
  else if(op == STORE){
    if(checkOps(node->val)== true){
      collect[count]= node->val;
      count++;
    }
  }
}
  
bool Parser::checkOps(string s){
  for(int i= 0; i<count; i++){
    if(s== collect[i]){
      return false;
    }
  }
  return true;
}
Parser::TreeNode* Parser::printfStatement(){
  
    TreeNode* paramList = NULL;
    int nparams = 0;
    check(Token::PRINTF, "Expecting printf");
    token = lexer.nextToken();
    check(Token::LPAREN, "Expecting (");
    token = lexer.nextToken();
    check(Token::STRINGLIT, "Expecting string literal");
    string formatString = token.getLexeme();
    token = lexer.nextToken();
    if (token.getType() == Token::COMMA) {
      token = lexer.nextToken();
      paramList = expression();
      ++nparams;
      while (token.getType() == Token::COMMA) {
	token = lexer.nextToken();
	paramList = new TreeNode(SEQ, paramList, expression());
	++nparams;
      }
    }
    check(Token::RPAREN, "Expecting )");
    token = lexer.nextToken();
    check(Token::SEMICOLON, "Expecting ;");
    token = lexer.nextToken();
     TreeNode* printStatement =
       new TreeNode(SEQ, paramList, new TreeNode(PRINTF, itos(nparams) + formatString));
     return printStatement;
}
string currentFunc;
int nfmts = 0;
string fmts[100];


void Parser::genasm(TreeNode *node){
   cout << "global main" << endl;
   cout << "extern printf" << endl;
   cout << "segment .bss" << endl;
   vardefs(node);
   for(int i = 1; i < count; i++){
     cout<< " " + collect[i] + " resq 1 " << endl;
     
   }
   cout << " section .text" <<endl;
   geninst(node);
   cout << endl << "  section .data" << endl;

   for (int i=0; i < nfmts; ++i) {

     cout << "  fmt" << i+1 << ": db " << fmts[i] << ", 0" << endl;

   }
}

void Parser::geninst(TreeNode *node){
  int nparams = 0;
  string fmt = " ";
  
  if(node==NULL){
    return;
      }
    geninst(node-> leftChild);
    geninst(node-> rightChild);
    Operation ops = node->op;
    switch(ops){
    case ADD :
      emit("   pop rbx");
      emit("   pop rax");
      emit("   add rax,rbx");
      emit("   push rax");
      break;

    case SUB :
      emit("   pop rbx");
      emit("   pop rax");
      emit("   sub rax,rbx");
      emit("   push rax");
      
      break;
    case AND :
      emit("   pop rbx");
      emit("   pop rax");
      emit("   and rax,rbx");
      emit("   push rax");
      break;
    case OR :
      emit("   pop rbx");
      emit("   pop rax");
      emit("   or rax,rbx");
      emit("   push rax");
      break;
    case MULT :
      emit("   pop rbx");
      emit("   pop rax");
      emit("   imul rbx");
      emit("   push rax");
      break;
    case DIV :
      emit("   mov rdx, 0");
      emit("   pop rbx");
      emit("   pop rax");
      emit("   idiv rbx");
      emit("   push rax");
      break;
    case LABEL :
      emit(node->val );
      break;
    case ISEQ :
      jumpL("   je");
      break;
    case ISNE :
      jumpL("   jne");
      break;
    case ISLT :
   jumpL(   "jl");
      break;
    case ISLE :
   jumpL("   jle");
      break;
    case ISGT :
   jumpL("   jg");
      break;
    case ISGE :
   jumpL("   jge");
      break;
    case JUMP :
      emit("   jmp " + node->val);
      break;
    case JUMPF :
      emit("   pop rax");
      emit("   cmp rax, 0");
      emit("   je " + node->val);
      break;
    case JUMPT :
      emit("   pop rax");
      emit("   cmp rax,0");
      emit("   jne " + node->val);
      break;
    case PUSHV :
      emit("   push qword[" + node->val + "]");
      break;
    case PUSHL :
      emit("   mov rax," + node->val);
      emit("   push rax");
      break;
    case STORE :
      emit("   pop qword[" + node->val + "]");
      break; 
    case PRINTF :
      fmt = node->val;
      nparams = fmt.at(0) - '0';
      fmt = "`" + fmt.substr(1) + "`";
      fmts[nfmts++] = fmt;
      emit("   mov rdi,fmt" + itos(nfmts));
      if (nparams == 5) {
	emit("   pop r9");
	--nparams;
      }
      if (nparams == 4) {
	emit("   pop r8");
	--nparams;
      }
      if (nparams == 3) {
	emit("   pop rcx");
	--nparams;
      }
      if (nparams == 2) {
	emit("   pop rdx");
	--nparams;
      }
      if (nparams == 1) {
	emit("   pop rsi");
      }
      emit("   mov rax,0");
      emit("   push rbp");
      emit("   call printf");
      emit("   pop rbp");
      
      break;

    case CALL :
      emit("   call " +  node->val);
      emit("   push rax");
      break;
    case FUNC :

      currentFunc = node->val;
      emit(currentFunc);
      if (currentFunc != "main:")
	emit("   pop r15");
      break;

    case RET:
      emit("   pop rax");
      if (currentFunc != "main:")
      emit("   push r15");
      emit("   ret");
      break;
    case SEQ:

      break;

    case PARAM:

      break;
    }
    
  


    
}
void Parser::emit(string s){
  cout<<s<<endl;
}
Parser::TreeNode* Parser::funcall(string str){
  TreeNode* functions;

  check(Token::LPAREN, "Expecting LPAREN");
  if(token.getType()==Token::LPAREN){
    token = lexer.nextToken();}
  if(token.getType()!= Token::RPAREN)
    {
      functions = expression();
    }
    else
      {
	return new TreeNode(Parser::CALL, str);
      }

  token = lexer.nextToken();
  while(token.getType() != Token::RPAREN)
    {
      functions = new TreeNode(Parser::SEQ, functions, expression());
      if(token.getType() == Token::COMMA)
	{
	  token = lexer.nextToken();
	}
    }

functions = new TreeNode(Parser::SEQ, functions, new TreeNode(Parser::CALL, str));

   
 check(Token::RPAREN, "EXPECTING )");
 token = lexer.nextToken();
  return functions;
}

Parser::TreeNode* Parser::factor() {
  TreeNode* node;
  int tokentype = token.getType();
  string save;
  switch(tokentype){

  case Token::LPAREN :
    token = lexer.nextToken();
    node = expression();
    check(Token::RPAREN, "Expecting RPAREN");
    token = lexer.nextToken();
    break;

  case Token::INTLIT :
    node = new TreeNode(PUSHL, token.getLexeme());
    token = lexer.nextToken();
    break;

  case Token::IDENT :
     if(token.getType() == Token::IDENT){
    string lexstore= token.getLexeme();
    token= lexer.nextToken();
    if(token.getType()== Token::LPAREN){
      node = funcall(lexstore);
    }
    else {
      string symbol= table.getUniqueSymbol(lexstore);
      if(symbol == ""){
	error("empty string");
      }
      // cout<<"I should be pushing v "<< endl;
	node = new TreeNode(PUSHV,symbol);
	//	cout<<" I am this symbol " << symbol<< endl;     
      }
     }
  
    break;

  default:
    error("Need a left param, integer, ident, or a function call");
    break;
  }

  return node;
}

Parser::TreeNode* Parser::term() {
  TreeNode* term = factor();
  TreeNode* factors;
  int tokentype = token.getType();

   while(tokentype == Token::TIMES || tokentype == Token::DIVIDE){
    token = lexer.nextToken();
    factors = factor();
    Operation op;
    switch (tokentype){

    case Token::TIMES :
      op = MULT;
      break;

    case Token::DIVIDE :
      op = DIV;
      break;

    default:
      error("Need multiplication or division");
      break;
    }

    term = new TreeNode(op, term, factors);
    tokentype = token.getType();
  }
  return term;
}

Parser::TreeNode* Parser::expression() {
  TreeNode* expression = term();
  TreeNode* terms;
  int type = token.getType();
  Operation op;

  while(type == Token::PLUS || type == Token::MINUS){
    token = lexer.nextToken();
    terms = term();

    switch (type){
    case Token::PLUS :
      op = ADD;
      break;

    case Token::MINUS :
      op = SUB;
      break;

    default:
      error("Need addition or subtraction");
      break;
    }

    expression = new TreeNode(op, expression, terms);
    type = token.getType();

  }
  return expression;
}

Parser::TreeNode* Parser::relationalExpression() {
  TreeNode* relation = expression();
  TreeNode* node;
  int type = token.getType();
  Operation op;

  switch(type){
  case Token::EQ :
    op = ISEQ;
    token = lexer.nextToken();
    node = expression();
    relation = new TreeNode(op, relation, node);
    break;

  case Token::LT :
    op = ISLT;
    token = lexer.nextToken();
    node = expression();
    relation = new TreeNode(op, relation, node);
    break;

  case Token::LE :
    op = ISLE;
    token = lexer.nextToken();
    node = expression();
    relation = new TreeNode(op, relation, node);
    break;

  case Token::GT :
    op = ISGT;
    token = lexer.nextToken();
    node = expression();
    relation = new TreeNode(op, relation, node);
    break;

  case Token:: GE :
    op = ISGE;
    token = lexer.nextToken();
    node = expression();
    relation = new TreeNode(op, relation, node);
    break;

  case Token:: NE :
    op = ISNE;
    token = lexer.nextToken();
    node = expression();
    relation = new TreeNode(op, relation, node);
    break;
  }
  return relation;
}

Parser::TreeNode* Parser::logicalExpression() {
  TreeNode* logic = relationalExpression();
  TreeNode* rel;
  int tokentype = token.getType();
  Operation op;

  while(tokentype == Token::AND || tokentype == Token::OR){
    token = lexer.nextToken();
    rel = relationalExpression();

    switch (tokentype){
    case Token::AND :
      op = AND;
      break;

    case Token::OR :
      op = OR;
      break;

    default:
      error("Need AND or OR");
      break;
    }

    logic = new TreeNode(op, logic, rel);
    tokentype = token.getType();
  }
  return logic;
}

Parser::TreeNode* Parser::ifStatement() {
  check(Token::IF, "Expecting if");
  token = lexer.nextToken();
  check(Token::LPAREN, "Expecting LPAREN");
  token = lexer.nextToken();

  TreeNode* ifNode;
  ifNode = logicalExpression();
  check(Token::RPAREN, "Expecting RPAREN");
  string l1 = makeLabel();
  string l2 = makeLabel();

  TreeNode* jfalse = new TreeNode(JUMPF, l1);
  ifNode = new TreeNode(SEQ, ifNode, jfalse);
  token = lexer.nextToken();
  table.enterScope();
  TreeNode* block1 = block();
  table.exitScope();
  ifNode = new TreeNode(SEQ, ifNode, block1);
  TreeNode* label1 = new TreeNode(LABEL, l1 + ":");
  if(token.getType()==Token::ELSE){
    TreeNode* block2 = block();
    TreeNode* jump = new TreeNode(JUMP, l2);
    ifNode = new TreeNode(SEQ, ifNode, jump);
    ifNode = new TreeNode(SEQ, ifNode, label1);
    ifNode = new TreeNode(SEQ, ifNode, block2);
    TreeNode* label2 = new TreeNode(LABEL, l2 + ":");
    ifNode = new TreeNode(SEQ, ifNode, label2);
  }
  else{
    ifNode = new TreeNode(SEQ, ifNode, label1);
  }
  return ifNode;
}

Parser::TreeNode* Parser::whileStatement() {
  TreeNode* whileNode;
  check(Token::WHILE, "Expecting WHILE");
  token = lexer.nextToken();

  check(Token::LPAREN, "Expecting LPAREN");
  token = lexer.nextToken();

  TreeNode* logic = logicalExpression();
  check(Token::RPAREN, "Expecting RPAREN");
  token = lexer.nextToken();
  string l1 = makeLabel();
  string l2 = makeLabel();

  whileNode = new TreeNode(LABEL, l1 + ":");
  whileNode = new TreeNode(SEQ, whileNode, logic);

  TreeNode* jfalse = new TreeNode(JUMPF, l2);
  whileNode = new TreeNode(SEQ, whileNode, jfalse);
  table.enterScope();
  TreeNode* blockN = block();
  table.exitScope();
  token = lexer.nextToken();
  whileNode = new TreeNode(SEQ, whileNode, blockN);

  TreeNode* jumpNode = new TreeNode(JUMP, l1);
  whileNode = new TreeNode(SEQ, whileNode, jumpNode);

  TreeNode* label2 = new TreeNode(LABEL, l2 + ":");
  whileNode = new TreeNode(SEQ, whileNode, label2);

  return whileNode;
}

Parser::TreeNode* Parser::assignStatement() {
  TreeNode* assign;
  TreeNode* id;

  check(Token::IDENT, "Must be an Identifier");
  string str = token.getLexeme();
  //cout<< "in assign im this string " << str << endl;
  //token = lexer.nextToken();
  string lexstore= table.getUniqueSymbol(str);
  //cout<< "this is my symbol in assign " << lexstore << endl;
  if(lexstore == ""){
    error("not declared");
  }
 id = new TreeNode(STORE, lexstore);

  
 token=lexer.nextToken();
  check(Token::ASSIGN, "Should be =");
   token = lexer.nextToken();
  assign = logicalExpression();

  check(Token::SEMICOLON, "Must be a semicolon");
  assign = new TreeNode(SEQ, assign, id);
  token = lexer.nextToken();
  return assign;
}

Parser::TreeNode* Parser::returnStatement(){
  TreeNode* returnNode= NULL;
  TreeNode* logic;

  check(Token::RETURN, "Expecting return");
  token= lexer.nextToken();
  logic= logicalExpression();
 
  returnNode= new TreeNode(SEQ, logic, new TreeNode(Parser::RET));

  check(Token::SEMICOLON, "Expecting semicolon");
  token= lexer.nextToken();

  return returnNode;
}
Parser::TreeNode* Parser::vardefStatement()
{


  check(Token::VAR, "Expecting var");
  token = lexer.nextToken();
  check(Token::IDENT, "Expecting ident");
  if((table.getUniqueSymbol(token.getLexeme()) != ""))
    {
      error("has already been declared");
    }
    table.addSymbol(token.getLexeme());
    token = lexer.nextToken();
		    
  while( token.getType()== Token::COMMA)
    {
    token= lexer.nextToken();
    check(Token::IDENT, " Expecting ident");

    if(table.getUniqueSymbol(token.getLexeme()) != "")
     {  
      error("has already been declared");
    }
    table.addSymbol(token.getLexeme());
    token = lexer.nextToken();
		   
    }
  check(Token::SEMICOLON, "Expecting semicolon");
  token= lexer.nextToken();
  return new TreeNode(Parser::SEQ);
    
} 

Parser::TreeNode* Parser::statement() {
  TreeNode* statement;
 

  switch(token.getType()){
  case Token::IDENT:
    statement = assignStatement();
    break;
  case Token::WHILE:
    statement = whileStatement();
    break;
  case Token::IF:
    statement = ifStatement();
    break;
  case Token::VAR:
    statement = vardefStatement();
    break;
  case Token::RETURN:
    statement = returnStatement();
    break;
  case Token::PRINTF:
    statement = printfStatement();
    break;
  default:
    error(token.getLexeme());
    break;
  }

  return statement;
}

Parser::TreeNode* Parser::block() {
  TreeNode* block = new TreeNode(ADD);
  int type = token.getType();
  check(Token::LBRACE, "Expecting LBRACE");
  if(type == Token::LBRACE){
    token = lexer.nextToken();
    block = statement();
    while(token.getType() != Token::RBRACE){
      block = new TreeNode(Parser::SEQ, block, statement());
    // token = lexer.nextToken();
    }
    check(Token::RBRACE, "Expecting RBRACE");
  }
  return block;
}

Parser::TreeNode* Parser::parameterdef(){
  Token temp = token;
  if(temp.getType()== Token::IDENT){
    token = lexer.nextToken();
    TreeNode* par= new TreeNode(PUSHV, temp.getLexeme());
    return par;
  }
  else {
    return NULL;
  }
}

Parser::TreeNode* Parser::parameterdefs(){
  TreeNode *node = parameterdef();
  if(node == NULL){
    return NULL;
  }

  while(token.getType() == Token::COMMA){
    node = new TreeNode(SEQ, node, parameterdef());
  }

  return node;
}


Parser::TreeNode* Parser::function(){
 
  TreeNode* functions;
  int i= 0;   
  check(Token::FUNCTION, "Expecting function");
  token = lexer.nextToken();
  check(Token::IDENT, "Expecting ident");
  functions = new TreeNode(FUNC, token.getLexeme());
  string name= token.getLexeme();
  token=lexer.nextToken();
  check(Token::LPAREN, "Expecting (");

  token = lexer.nextToken();
  string param[53];
  table.enterScope();
  if(token.getType() != Token::RPAREN)
    {
      check(Token::IDENT, "Expecting Parameter");
      string lex= token.getLexeme();
      param[i] = lex;
      token= lexer.nextToken();
      while(token.getType()== Token::COMMA)
	{
	  i++;
	  token= lexer.nextToken();
	  lex= token.getLexeme();
	  param[i]= lex;

	  token= lexer.nextToken();
	}
    }
  check(Token::RPAREN, "Expecting )");
  token= lexer.nextToken();
  functions= new TreeNode(FUNC, name + ":");
  for(int index= i; index>= 0; index--)
    {
      int add= table.addSymbol(param[index]);
      if(add==0)
	{
	  error("variable must be declared in this scope");
	}
      string temp= table.getUniqueSymbol(param[i]);
      functions = new TreeNode(SEQ, functions, new TreeNode(Parser::STORE, temp))\
	;
    }
  TreeNode* blockN= block();
 table.exitScope();
  functions = new TreeNode(SEQ, functions, blockN);
 
  token = lexer.nextToken();
  return functions;
 

}

Parser::TreeNode* Parser::compilationunit(){
  TreeNode* cunit= function();
  check(Token::FUNCTION, " Expecting Function");
  while(token.getType()!= Token::ENDOFFILE){
    cunit= new TreeNode(SEQ, cunit, function());
  }
  return cunit;
}





