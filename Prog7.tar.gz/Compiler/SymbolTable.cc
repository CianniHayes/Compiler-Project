
#include <stdio.h>
#include "parser.h"
#include "Trie.h"
#include "token.h"
#include "lexer.h"
#include "SymbolTable.h"
#include "stack.cc"
#include "hashTable.h"
#include <iostream>

 string itos(int i) { stringstream ss; ss << i; string res = ss.str(); return    res;}

SymbolTable::SymbolTable(): index(0){

}

SymbolTable:: ~SymbolTable(){
 
}

void SymbolTable::exitScope(){
  symtable.pop();



}


void SymbolTable::enterScope(){
  symtable.push(HashTable(53));
}
  


int SymbolTable::addSymbol(string sym){

  HashTable& top= symtable.peek();
  if(top.inTable(sym)){
    return 0;   
}
  symtable.peek().add(sym, sym + "$" + itos(index++));
  return 1;
}
string SymbolTable::getUniqueSymbol(string sym){
  for(int i= symtable.getTos(); i>= 0; --i){
    HashTable& sc= symtable[i];
    if(sc.inTable(sym)){
      return sc[sym];
    }
  }
  return "";

}

