#include <cstdlib>
#include <stdio.h>
#include "Link.h"
#include <iostream>
Link::Link(){
  next= ' ';
  move= new Node();
}
Link::Link(char letter, Node* point){
  move= point;
  next= letter;

}

Link::~Link(){
  next= NULL;
  delete move;
}





